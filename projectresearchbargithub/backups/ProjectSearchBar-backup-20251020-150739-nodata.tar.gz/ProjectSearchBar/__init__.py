# Make ProjectSearchBar a package

